﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KonferenciaProjekt
{
    class Eloadas
    {
        string cim;
        int sorDb;
        int helyDb;
        int[,] ertekeles;

        public Eloadas(string cim, int sorDb, int helyDb, int[,] ertekeles)
        {
            this.Cim = cim;
            this.SorDb = sorDb;
            this.HelyDb = helyDb;
            this.Ertekeles = ertekeles;
        }

        public string Cim { get => cim; set => cim = value; }
        public int SorDb { get => sorDb; set => sorDb = value; }
        public int HelyDb { get => helyDb; set => helyDb = value; }
        public int[,] Ertekeles { get => ertekeles; set => ertekeles = value; }

        public double Atlag
        {
            get
            {
                int osszeg = 0;
                int darab = 0;
                foreach (var item in ertekeles)
                {
                    if(item != 0)
                    {
                        osszeg += item;
                        darab++;
                    }
                }
                return osszeg*1.0 / darab;
            }
        }

    }
}
