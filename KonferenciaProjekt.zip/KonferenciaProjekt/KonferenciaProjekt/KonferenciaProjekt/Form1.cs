﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KonferenciaProjekt
{
    public partial class Form1 : Form
    {
        Konferencia k;
        int eloadasIndex;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                k = new Konferencia("konferencia.txt");
                eloadasIndex = 0;
                Megjelenit();
            }
            catch (Exception)
            {
                MessageBox.Show("Hiba");
                this.Close();
            }
        }

        private void Megjelenit()
        {
            var eloadas = k.Eloadasok[eloadasIndex];
            this.Text = String.Format("{0} ({1:0.0})",eloadas.Cim, eloadas.Atlag);
            pbNev.Image = Image.FromFile("Kepek/" + eloadas.Cim.Split()[0] + ".jpg");
            panel.Controls.Clear();
            panel.Width = eloadas.HelyDb * 50;
            panel.Height = eloadas.SorDb * 50;
            for (int i = 0; i < eloadas.SorDb; i++)
            {
                for (int j = 0; j < eloadas.HelyDb; j++)
                {
                    var gomb = new PictureBox(); //PictureBox picturebox
                    gomb.Width = 50;
                    gomb.Height = 50;
                    gomb.Top = i* 50;
                    gomb.Left = j* 50;
                    gomb.SizeMode = PictureBoxSizeMode.StretchImage;
                    gomb.Image = Image.FromFile("Kepek/Pont" + eloadas.Ertekeles[i,j] + ".jpg");
                    

                    int i1 = i;
                    int j1 = j;
                    gomb.MouseUp += (sender, e) =>
                    {
                        if(e.Button == MouseButtons.Left)
                        {
                            if(eloadas.Ertekeles [i1, j1] == 0)
                            {
                                MessageBox.Show("Itt nem ül senki!");
                            }
                            else
                            {
                                eloadas.Ertekeles[i1, j1]++;
                                if(eloadas.Ertekeles[i1,j1] > 3)
                                {
                                    eloadas.Ertekeles[i1, j1] = 1;
                                }
                                gomb.Image = Image.FromFile("Kepek/Pont" + eloadas.Ertekeles[i1, j1] + ".jpg");
                                this.Text = String.Format("{0} ({1:0.0})", eloadas.Cim, eloadas.Atlag); //{0} nulladik elem matrixban ({1: -> cim, atlag ha 0-lenne akkor csak cim, :0.0 -> jelenitse meg a szamot es egy tizedesjegy poontossaggal szeretnem megkapni
                            }
                        }
                    };
                    panel.Controls.Add(gomb);
                }
            }
        }

        private void pbJobb_Click(object sender, EventArgs e)
        {
            eloadasIndex++;
            if(eloadasIndex == k.Eloadasok.Count)
            {
                eloadasIndex = 0;
            }
            Megjelenit();
        }

        private void pbBal_Click(object sender, EventArgs e)
        {
            eloadasIndex--;
            if(eloadasIndex < 0)
            {
                eloadasIndex = k.Eloadasok.Count - 1;
            }
            Megjelenit();
        }

        private void pbMent_Click(object sender, EventArgs e)
        {
            try
            {
                File.Copy("konferencia.txt", "konferencia.bak", true);
                using( var sw = new StreamWriter("konferencia.txt"))
                {
                    foreach (var item in k.Eloadasok)
                    {
                        sw.WriteLine(item.Cim);
                        sw.WriteLine(item.SorDb+ ";" + item.HelyDb);
                        for (int i = 0; i < item.SorDb; i++)
                        {
                            sw.Write(item.Ertekeles[i, 0]);
                            for (int j = 0; j < item.HelyDb; j++)
                            {
                                sw.Write(";" + item.Ertekeles[i,j]);
                            }
                            sw.WriteLine();
                        }
                        sw.WriteLine();
                    }
                }
                
                MessageBox.Show("Sikeres mentés");
            }
            catch (Exception)
            {
                MessageBox.Show("sikertelen mentés");
            }
        }
    }
}
