﻿namespace KonferenciaProjekt
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel = new System.Windows.Forms.Panel();
            this.pbNev = new System.Windows.Forms.PictureBox();
            this.pbBal = new System.Windows.Forms.PictureBox();
            this.pbJobb = new System.Windows.Forms.PictureBox();
            this.pbMent = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbNev)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbJobb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMent)).BeginInit();
            this.SuspendLayout();
            // 
            // panel
            // 
            this.panel.Location = new System.Drawing.Point(344, 64);
            this.panel.Name = "panel";
            this.panel.Size = new System.Drawing.Size(418, 302);
            this.panel.TabIndex = 0;
            // 
            // pbNev
            // 
            this.pbNev.Location = new System.Drawing.Point(80, 55);
            this.pbNev.Name = "pbNev";
            this.pbNev.Size = new System.Drawing.Size(154, 198);
            this.pbNev.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbNev.TabIndex = 1;
            this.pbNev.TabStop = false;
            // 
            // pbBal
            // 
            this.pbBal.Image = global::KonferenciaProjekt.Properties.Resources.bal;
            this.pbBal.Location = new System.Drawing.Point(13, 152);
            this.pbBal.Name = "pbBal";
            this.pbBal.Size = new System.Drawing.Size(58, 60);
            this.pbBal.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbBal.TabIndex = 2;
            this.pbBal.TabStop = false;
            this.pbBal.Click += new System.EventHandler(this.pbBal_Click);
            // 
            // pbJobb
            // 
            this.pbJobb.Image = global::KonferenciaProjekt.Properties.Resources.jobb;
            this.pbJobb.Location = new System.Drawing.Point(240, 152);
            this.pbJobb.Name = "pbJobb";
            this.pbJobb.Size = new System.Drawing.Size(61, 60);
            this.pbJobb.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbJobb.TabIndex = 3;
            this.pbJobb.TabStop = false;
            this.pbJobb.Click += new System.EventHandler(this.pbJobb_Click);
            // 
            // pbMent
            // 
            this.pbMent.Image = global::KonferenciaProjekt.Properties.Resources.ment;
            this.pbMent.Location = new System.Drawing.Point(134, 292);
            this.pbMent.Name = "pbMent";
            this.pbMent.Size = new System.Drawing.Size(47, 50);
            this.pbMent.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbMent.TabIndex = 4;
            this.pbMent.TabStop = false;
            this.pbMent.Click += new System.EventHandler(this.pbMent_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pbMent);
            this.Controls.Add(this.pbJobb);
            this.Controls.Add(this.pbBal);
            this.Controls.Add(this.pbNev);
            this.Controls.Add(this.panel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbNev)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbJobb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMent)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel;
        private System.Windows.Forms.PictureBox pbNev;
        private System.Windows.Forms.PictureBox pbBal;
        private System.Windows.Forms.PictureBox pbJobb;
        private System.Windows.Forms.PictureBox pbMent;
    }
}

