﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KonferenciaProjekt
{
    class Konferencia
    {
        List<Eloadas> eloadasok;

        internal List<Eloadas> Eloadasok { get => eloadasok; set => eloadasok = value; }

        public Konferencia(string filenev)
        {
            eloadasok = new List<Eloadas>();
            using(var sr = new StreamReader(filenev))
            {
                while (!sr.EndOfStream)
                {
                    string cim = sr.ReadLine();
                    string[] st = sr.ReadLine().Split(';');
                    int sorDb = Convert.ToInt32(st[0]);
                    int helyDb = Convert.ToInt32(st[1]);
                    int[,] ertekeles = new int[sorDb, helyDb];
                    for (int i = 0; i < sorDb; i++)
                    {
                        string[] sor = sr.ReadLine().Split(';'); 
                        for (int j = 0; j < helyDb; j++)
                        {
                            ertekeles[i, j] = int.Parse(sor[j]);
                        }
                    }
                    sr.ReadLine();
                    var eloadas = new Eloadas(cim, sorDb, helyDb, ertekeles);
                    eloadasok.Add(eloadas);
                }
            }
        }
    }
}
